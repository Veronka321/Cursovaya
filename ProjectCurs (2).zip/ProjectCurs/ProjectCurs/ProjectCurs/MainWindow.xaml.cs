﻿    using System;
using System.Windows;
using System.Numerics;

namespace ProjectCurs
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public static decimal learningRate_one = 0.01M;

        private void Method_1_1_Click(object sender, RoutedEventArgs e)
        {
            int[] numSteps = { 10, 50, 100, 250, 500, 1000, 5000, 10000, 100000, 1000000 };

            // Запускаем таймер
            DateTime startTime = DateTime.Now;
            TimeSpan elapsedTime = startTime - startTime;

            foreach (int steps in numSteps)
            {
                decimal currentX = 0.0M;

                // Выполняем градиентный метод спуска
                decimal result = GradientDescentMethod(currentX, steps);

                // Останавливаем таймер
                DateTime endTime = DateTime.Now;

                // Вычисляем время выполнения метода
                elapsedTime += endTime - startTime;

                // Выводим результат и время выполнения
                spusk.Items.Add("Результат на " + steps + " шаге: " + result);
                spusk.Items.Add("Время выполнения метода на " + steps + " шаге: " + elapsedTime.TotalMilliseconds + "  мс");
                spusk.Items.Add("");
            }

        }

        public static decimal GradientDescentMethod(decimal currentX, int numSteps)
        {
            for (int i = 0; i < numSteps; i++)
            {
                // Выполняем шаг градиентного спуска
                decimal gradient = ComputeGradient(currentX);
                decimal step = gradient * learningRate_one;
                decimal proiz = gradient * currentX / 3 + 3 * (currentX - 1) / 2;
                currentX = currentX- step*proiz;
            }

            return currentX;
        }

        public static decimal learningRate_two = 0.01M;

        private void Method_2_1_Click(object sender, RoutedEventArgs e)
        {
            int[] numSteps = { 10, 50, 100, 250, 500, 1000, 5000, 10000, 100000, 1000000};

            // Запускаем таймер
            DateTime startTime = DateTime.Now;
            TimeSpan elapsedTime = startTime - startTime;

            foreach (int steps in numSteps)
            {
                decimal currentX = 0.0M;

                // Выполняем градиентный метод отсечения
                decimal result = CuttingGradientMethod(currentX, steps);

                // Останавливаем таймер
                DateTime endTime = DateTime.Now;

                // Вычисляем время выполнения метода
                elapsedTime += endTime - startTime;

                // Выводим результат и время выполнения
                otsechenia.Items.Add("Результат на " + steps + " шаге: " + result);
                otsechenia.Items.Add("Время выполнения метода на " + steps + " шаге: " + elapsedTime.TotalMilliseconds + " мс");
                otsechenia.Items.Add("");
            }
        }

        public static decimal CuttingGradientMethod(decimal currentX, int numSteps)
        {
            decimal gradient = ComputeGradient(currentX); //f(x)
            for (int i = 0; i <= numSteps; i++)
            {
                // Выполняем шаг градиентного спуска
                decimal n = 10 /(i + 1);                           //(Nk )
                decimal y = 0.5M;
                decimal O = gradient + n;
                decimal proiz = gradient * currentX / 3 + 3 * (currentX - 1) / 2;
                decimal z = currentX - Math.Abs(proiz) / y;
                //decimal fi= gradient - Math.Abs(proiz)* (proiz) / (2*y);
                decimal step = gradient * learningRate_two;
                currentX = currentX - step*(z - currentX);
                //gradient = O - step*(fi - O);
                // currentX = Math.Max(z+step, 0.0);
            }
            return currentX;
        }

        public static decimal ComputeGradient(decimal x)
        {
            // Вычисляем градиент по формуле:+
            
            decimal gradient = 0.5M * (x - 1) * (x - 1) + (1 / 3) * x * x + 0.25M * (x - 1) * (x - 1);
            //decimal grad =Math.Round(gradient, 6);
            return gradient;
        }

        private void Method_2_2_Click(object sender, RoutedEventArgs e)
        {
            otsechenia.Items.Clear();
        }

        private void Method_1_2_Click(object sender, RoutedEventArgs e)
        {
            spusk.Items.Clear();
        }
    }
}
